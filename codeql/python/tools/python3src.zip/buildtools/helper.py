
import os
import traceback
import re
SCRIPTDIR = os.path.split(os.path.dirname(__file__))[1]

def print_exception_indented(opt=None):
    exc_text = traceback.format_exc()
    for line in exc_text.splitlines():
        line = re.sub((('File \\".*' + SCRIPTDIR) + '(.*)\\",'), (('File <' + SCRIPTDIR) + '\\1>'), line)
        print(('    ' + line))
