

class BaseExtractor(object):

    def __init__(self, options, trap_folder, src_archive, logger):
        self.options = options
        self.trap_folder = trap_folder
        self.src_archive = src_archive
        self.logger = logger

    def process(self, unit):
        raise NotImplementedError()
